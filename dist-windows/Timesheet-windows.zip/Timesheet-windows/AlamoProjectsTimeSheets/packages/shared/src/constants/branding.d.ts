export declare const BRANDING: {
    readonly product: "Timesheet";
    readonly subtitle: "for Alamo Projects";
    readonly footer: "Innoweb Ventures Limited";
};
