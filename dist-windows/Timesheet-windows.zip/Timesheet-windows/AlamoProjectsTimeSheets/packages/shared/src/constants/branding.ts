export const BRANDING = {
  product: "Workbook",
  subtitle: "for Alamo Projects",
  footer: "Innoweb Ventures Limited"
} as const;
