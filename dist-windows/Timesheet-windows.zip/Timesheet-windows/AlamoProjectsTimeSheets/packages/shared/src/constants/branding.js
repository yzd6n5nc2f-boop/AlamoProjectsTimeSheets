export const BRANDING = {
    product: "Timesheet",
    subtitle: "for Alamo Projects",
    footer: "Innoweb Ventures Limited"
};
//# sourceMappingURL=branding.js.map