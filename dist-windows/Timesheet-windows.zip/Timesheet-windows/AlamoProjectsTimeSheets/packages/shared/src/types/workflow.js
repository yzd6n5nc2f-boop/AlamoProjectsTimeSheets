export const WORKFLOW_STATUSES = [
    "DRAFT",
    "SUBMITTED",
    "MANAGER_APPROVED",
    "MANAGER_REJECTED",
    "PAYROLL_VALIDATED",
    "LOCKED"
];
export const USER_ROLES = ["EMPLOYEE", "MANAGER", "PAYROLL", "ADMIN"];
//# sourceMappingURL=workflow.js.map