Timesheet Windows Bundle

How to run:
1) Open Timesheet.exe
2) The launcher will try Docker staging stack first.
3) If Docker is unavailable, it falls back to frontend-only mode at http://localhost:3000.

Requirements on the Windows machine:
- Node.js 20+
- npm
- Docker Desktop (optional but recommended for full stack)
